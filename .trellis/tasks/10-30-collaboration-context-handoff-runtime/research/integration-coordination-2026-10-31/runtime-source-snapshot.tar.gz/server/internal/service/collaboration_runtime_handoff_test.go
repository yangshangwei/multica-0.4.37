package service

import (
	"context"
	"encoding/json"
	"testing"

	"github.com/google/uuid"
	"github.com/multica-ai/multica/server/internal/util"
	"github.com/multica-ai/multica/server/pkg/protocol"
)

func TestCollaborationHandoffFrozenAssignmentAndSnapshot(t *testing.T) {
	f, member := newManagedSquadFixture(t)
	f.submitManaged(t, f.creator, "Original intent, preserve this author")
	f.resumeManaged(t)
	root, request, claim := f.claimManaged(t)
	token, nonce := permitSquadRun(t, f, root, claim)
	instruction := "[@member](mention://agent/" + util.UUIDToString(member) + ") inspect only the parser"
	comment := util.MustParseUUID(uuid.NewString())
	receipt, err := f.svc.CreateRuntimeComment(context.Background(), root, token, CollaborationRuntimeCommentParams{CommentID: comment, Content: instruction})
	if err != nil {
		t.Fatal(err)
	}
	finishSquadRun(t, f, root, claim, token, nonce, "success")
	memberRun := receipt.RunIDs[0]
	memberClaim, err := f.svc.ClaimRuntimeRun(f.daemonCtx, memberRun, request)
	if err != nil {
		t.Fatal(err)
	}
	memberToken, memberNonce := permitSquadRun(t, f, memberRun, memberClaim)
	// The original admitted event remains authoritative after a current comment edit.
	if _, err = f.pool.Exec(f.ctx, "UPDATE comment SET content='changed comment must not change delegation',revision=revision+1 WHERE id=$1", comment); err != nil {
		t.Fatal(err)
	}
	current, err := f.svc.RuntimeContext(context.Background(), memberRun, memberToken)
	if err != nil || current.DispatchComment != instruction {
		t.Fatalf("dispatch: %+v %v", current, err)
	}
	p := protocol.CollaborationHandoffSnapshotRequest{RequestID: uuid.NewString(), MemoryVersion: ""}
	frozen, err := f.svc.RuntimeHandoffSnapshot(context.Background(), memberRun, memberToken, p)
	if err != nil {
		t.Fatal(err)
	}
	if frozen.Assignment.Role != "member" || frozen.Assignment.ParentRunID != util.UUIDToString(root) || frozen.Assignment.SourceID == "" {
		t.Fatalf("assignment: %+v", frozen.Assignment)
	}
	found := false
	for _, s := range frozen.Sources {
		if s.Kind == "delegation" {
			found = s.Content == instruction && s.Trust == "admitted_assignment"
		}
	}
	if !found {
		t.Fatal("admitted delegation was not projected")
	}
	if len(frozen.Inputs.Items) != 1 || len(frozen.Inputs.Items[0].ReaderRunIDs) != 2 {
		t.Fatalf("complete prompt readers absent: %+v", frozen.Inputs)
	}
	raw, _ := json.Marshal(frozen)
	replay, err := f.svc.RuntimeHandoffSnapshot(context.Background(), memberRun, memberToken, p)
	if err != nil {
		t.Fatal(err)
	}
	again, _ := json.Marshal(replay)
	if string(raw) != string(again) {
		t.Fatal("snapshot replay changed")
	}
	binding := protocol.CollaborationHandoffBinding{SnapshotID: p.RequestID, PromptSHA256: protocol.CollaborationHandoffHash("actual prompt"), AttemptSeq: "1", AttemptNonce: memberNonce}
	if _, err = f.svc.BindRuntimeHandoff(context.Background(), memberRun, memberToken, binding); err != nil {
		t.Fatal(err)
	}
	binding.PromptSHA256 = protocol.CollaborationHandoffHash("different prompt")
	if _, err = f.svc.BindRuntimeHandoff(context.Background(), memberRun, memberToken, binding); !collaborationErrorCode(err, "handoff_binding_conflict") {
		t.Fatalf("changed prompt accepted: %v", err)
	}
	if _, err = f.svc.StopQueue(f.ctx, f.issueControl(t)); err != nil {
		t.Fatal(err)
	}
	if _, err = f.svc.RuntimeHandoffSnapshot(context.Background(), memberRun, memberToken, p); err == nil {
		t.Fatal("revoked run recovered private snapshot")
	}
	human, err := f.svc.RunHandoff(f.ctx, f.issue.Issue.ID, memberRun, CollaborationHandoffQuery{})
	if err != nil || human.Assignment.SourceID == "" {
		t.Fatalf("human retained history: %+v %v", human, err)
	}
}

func TestCollaborationHandoffPreservesEveryMergedWakeCause(t *testing.T) {
	f, member := newManagedSquadFixture(t)
	f.submitManaged(t, f.creator, "root request")
	f.resumeManaged(t)
	root, request, claim := f.claimManaged(t)
	token, nonce := permitSquadRun(t, f, root, claim)
	receipt, err := f.svc.CreateRuntimeComment(context.Background(), root, token, CollaborationRuntimeCommentParams{CommentID: util.MustParseUUID(uuid.NewString()), Content: "[@member](mention://agent/" + util.UUIDToString(member) + ") work"})
	if err != nil {
		t.Fatal(err)
	}
	finishSquadRun(t, f, root, claim, token, nonce, "success")
	m := receipt.RunIDs[0]
	mc, err := f.svc.ClaimRuntimeRun(f.daemonCtx, m, request)
	if err != nil {
		t.Fatal(err)
	}
	mt, mn := permitSquadRun(t, f, m, mc)
	for i := 0; i < 2; i++ {
		if _, err = f.svc.CreateRuntimeComment(context.Background(), m, mt, CollaborationRuntimeCommentParams{CommentID: util.MustParseUUID(uuid.NewString()), Content: "member evidence"}); err != nil {
			t.Fatal(err)
		}
	}
	finishSquadRun(t, f, m, mc, mt, mn, "failure")
	continuation, _, cc := f.claimManaged(t)
	ct, _ := permitSquadRun(t, f, continuation, cc)
	envelope, err := f.svc.RuntimeHandoff(context.Background(), continuation, ct, CollaborationHandoffQuery{})
	if err != nil {
		t.Fatal(err)
	}
	counts := map[string]int{}
	for _, c := range envelope.WakeupCauses.Items {
		counts[c.SourceKind]++
	}
	if counts["comment"] != 2 || counts["proof"] != 1 {
		t.Fatalf("merged sources lost: %+v", envelope.WakeupCauses)
	}
	if envelope.Results.Total < 3 {
		t.Fatalf("member results absent: %+v", envelope.Results)
	}
}
