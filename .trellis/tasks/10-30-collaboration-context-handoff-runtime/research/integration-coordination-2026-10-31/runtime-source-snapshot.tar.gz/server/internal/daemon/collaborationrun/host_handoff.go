package collaborationrun

import (
	"context"
	"errors"
	"net/http"
	"time"

	"github.com/google/uuid"
	"github.com/multica-ai/multica/server/pkg/protocol"
)

func (c *Client) HandoffSnapshot(ctx context.Context, identity protocol.CollaborationRunIdentity, token string, p protocol.CollaborationHandoffSnapshotRequest) (protocol.CollaborationHandoffEnvelope, error) {
	var out protocol.CollaborationHandoffEnvelope
	if validateIdentity(identity) != nil || !validUUID(p.RequestID) {
		return out, ErrProtocol
	}
	if err := c.request(ctx, http.MethodPost, runPath(identity.RunID, "handoff/snapshots"), token, p, &out); err != nil {
		return out, err
	}
	if out.RunID != identity.RunID || out.IssueID != identity.IssueID || out.SnapshotID != p.RequestID || out.Mode != "snapshot" || protocol.ValidateCollaborationHandoff(out) != nil {
		return out, ErrProtocol
	}
	return out, nil
}
func (c *Client) BindHandoff(ctx context.Context, identity protocol.CollaborationRunIdentity, token string, p protocol.CollaborationHandoffBinding) error {
	var out protocol.CollaborationHandoffBindingReceipt
	if err := c.request(ctx, http.MethodPost, runPath(identity.RunID, "handoff/bind"), token, p, &out); err != nil {
		return err
	}
	if out.ProtocolVersion != 1 || !out.Accepted || out.IssueID != identity.IssueID || out.RunID != identity.RunID || out.SnapshotID != p.SnapshotID || out.PromptSHA256 != p.PromptSHA256 || out.AttemptSeq != p.AttemptSeq || out.AttemptNonce != p.AttemptNonce {
		return ErrProtocol
	}
	return nil
}
func (r *Runner) hostHandoff(ctx context.Context, claim protocol.CollaborationRunClaimResponse, token string, memory *protocol.CollaborationRunMemory) (*protocol.CollaborationHandoffEnvelope, error) {
	if claim.HandoffVersion == 0 {
		return nil, nil
	}
	if claim.HandoffVersion != 1 {
		return nil, ErrProtocol
	}
	version := ""
	if memory != nil {
		version = memory.Version
	}
	request := protocol.CollaborationHandoffSnapshotRequest{RequestID: uuid.NewString(), MemoryVersion: version}
	var out protocol.CollaborationHandoffEnvelope
	err := r.retryHandoff(ctx, func() error {
		var e error
		out, e = r.Client.HandoffSnapshot(ctx, claim.Identity, token, request)
		return e
	})
	if err != nil {
		return nil, err
	}
	if memory != nil && (out.Memory.Version != memory.Version || out.Memory.Availability == "available" && out.Memory.SHA256 != protocol.CollaborationHandoffHash(memory.Content)) {
		return nil, ErrProtocol
	}
	return &out, nil
}
func (r *Runner) retryHandoff(ctx context.Context, call func() error) error {
	attempts, backoff := r.PermitAttempts, r.PermitBackoff
	if attempts <= 0 {
		attempts = defaultPermitAttempts
	}
	if backoff <= 0 {
		backoff = defaultPermitBackoff
	}
	var err error
	for i := 0; i < attempts; i++ {
		if i > 0 {
			timer := time.NewTimer(backoff<<i - 1)
			select {
			case <-timer.C:
			case <-ctx.Done():
				timer.Stop()
				return errors.Join(err, ctx.Err())
			}
		}
		err = call()
		if err == nil {
			return nil
		}
		var refusal *HTTPError
		if !errors.Is(err, ErrTransport) && !(errors.As(err, &refusal) && (refusal.Status == 408 || refusal.Status == 429 || refusal.Status >= 500)) {
			return err
		}
	}
	return err
}
func (s *hostSupervisor) bindHandoff(ctx context.Context) error {
	s.mu.Lock()
	snapshot, hash := s.handoffSnapshot, s.handoffPromptHash
	seq, nonce, token := s.local.record.AttemptSeq, s.local.record.AttemptNonce, s.local.record.Host.BusinessToken
	s.mu.Unlock()
	if snapshot == "" {
		if s.claim.HandoffVersion == 1 {
			return ErrProtocol
		}
		return nil
	}
	request := protocol.CollaborationHandoffBinding{SnapshotID: snapshot, PromptSHA256: hash, AttemptSeq: seq, AttemptNonce: nonce}
	return s.runner.retryHandoff(ctx, func() error { return s.runner.Client.BindHandoff(ctx, s.claim.Identity, token, request) })
}
func (s *hostSupervisor) setHandoff(handoff *protocol.CollaborationHandoffEnvelope, prompt string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.handoffSnapshot = ""
	s.handoffPromptHash = ""
	if handoff != nil {
		s.handoffSnapshot = handoff.SnapshotID
		s.handoffPromptHash = protocol.CollaborationHandoffHash(prompt)
	}
}
