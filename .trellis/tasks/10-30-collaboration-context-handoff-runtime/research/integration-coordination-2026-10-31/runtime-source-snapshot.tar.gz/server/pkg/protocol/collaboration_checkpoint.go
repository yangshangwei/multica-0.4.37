package protocol

import (
	"errors"
	"strconv"
)

const (
	CollaborationCheckpointVersion      = 1
	CollaborationCheckpointMessageLimit = 16
	CollaborationCheckpointBodyLimit    = 64 << 10
	CollaborationCheckpointCountLimit   = 256
	CollaborationRecordingBodyLimit     = 512 << 10
	CollaborationCheckpointJSONLimit    = 6*CollaborationCheckpointBodyLimit + 64<<10
)

// Recording offsets are zero-based message counts, independent of event sequence.
// They remain continuous across provider retries within one run.
type CollaborationRecordingCheckpoint struct {
	Version       int                            `json:"version"`
	Identity      CollaborationRunIdentity       `json:"identity"`
	AttemptSeq    string                         `json:"attempt_seq"`
	AttemptNonce  string                         `json:"attempt_nonce"`
	StreamID      string                         `json:"stream_id"`
	Sequence      int                            `json:"sequence"`
	MessageOffset int                            `json:"message_offset"`
	Messages      []CollaborationRecordedMessage `json:"messages"`
}

type CollaborationCheckpointReceipt struct {
	Version         int                      `json:"version"`
	Identity        CollaborationRunIdentity `json:"identity"`
	StreamID        string                   `json:"stream_id"`
	Sequence        int                      `json:"sequence"`
	RetainedThrough int                      `json:"retained_through"`
	Accepted        bool                     `json:"accepted"`
}

// A seal is metadata only. ObservedThrough=nil explicitly leaves the tail unknown.
// A sender's acknowledged count never replaces the server's committed prefix.
type CollaborationRecordingSeal struct {
	Version             int                      `json:"version"`
	Identity            CollaborationRunIdentity `json:"identity"`
	AttemptSeq          string                   `json:"attempt_seq"`
	AttemptNonce        string                   `json:"attempt_nonce"`
	StreamID            string                   `json:"stream_id"`
	ObservedThrough     *int                     `json:"observed_through"`
	AcknowledgedThrough int                      `json:"acknowledged_through"`
	Reason              string                   `json:"reason"`
}

type CollaborationRecordingRetention struct {
	Version         int    `json:"version"`
	StreamID        string `json:"stream_id"`
	RetainedThrough int    `json:"retained_through"`
	ObservedThrough *int   `json:"observed_through"`
	Sealed          bool   `json:"sealed"`
	Reason          string `json:"reason"`
}

func validCheckpointAttempt(identity CollaborationRunIdentity, seq, nonce, stream string) bool {
	n, err := strconv.Atoi(seq)
	return preparationIdentity(identity) && err == nil && n > 0 && n <= CollaborationHostMaxLaunches && strconv.Itoa(n) == seq && preparationUUID(nonce) && preparationUUID(stream)
}

func ValidateCollaborationRecordingCheckpoint(p CollaborationRecordingCheckpoint) error {
	invalid := errors.New("invalid collaboration recording checkpoint")
	if p.Version != CollaborationCheckpointVersion || !validCheckpointAttempt(p.Identity, p.AttemptSeq, p.AttemptNonce, p.StreamID) || p.Sequence < 1 || p.Sequence > CollaborationCheckpointCountLimit || p.MessageOffset < 0 || len(p.Messages) < 1 || len(p.Messages) > CollaborationCheckpointMessageLimit || p.MessageOffset+len(p.Messages) > CollaborationRecordItemLimit {
		return invalid
	}
	if ValidateCollaborationRunRecord(&CollaborationRunRecord{Version: 1, Completeness: "partial", Messages: p.Messages}) != nil {
		return invalid
	}
	total := 0
	for _, m := range p.Messages {
		total += len(m.Body)
	}
	if total > CollaborationCheckpointBodyLimit {
		return invalid
	}
	return nil
}

func ValidateCollaborationRecordingSeal(p CollaborationRecordingSeal) error {
	invalid := errors.New("invalid collaboration recording seal")
	if p.Version != CollaborationCheckpointVersion || !validCheckpointAttempt(p.Identity, p.AttemptSeq, p.AttemptNonce, p.StreamID) || p.AcknowledgedThrough < 0 || p.AcknowledgedThrough > CollaborationRecordItemLimit || p.ObservedThrough != nil && (*p.ObservedThrough < p.AcknowledgedThrough || *p.ObservedThrough > CollaborationRecordItemLimit || *p.ObservedThrough < 0) {
		return invalid
	}
	switch p.Reason {
	case "completed", "stopped", "authority_lost", "transport_error", "recording_limit", "incomplete":
	default:
		return invalid
	}
	if p.Reason == "completed" && p.ObservedThrough == nil {
		return invalid
	}
	return nil
}
