package protocol

import (
	"encoding/json"
	"testing"
)

func testHandoffEnvelope() CollaborationHandoffEnvelope {
	return CollaborationHandoffEnvelope{ProtocolVersion: 1, IssueID: "11111111-1111-4111-8111-111111111111", RunID: "22222222-2222-4222-8222-222222222222", Mode: "live", EventSequence: "0", Authority: CollaborationHandoffAuthority{Status: "todo"}, Assignment: CollaborationHandoffAssignment{Role: "agent"}, Memory: CollaborationHandoffMemory{Version: "0", Availability: "absent"}, Inputs: CollaborationHandoffInputs{Items: []CollaborationHandoffInput{}}, Results: CollaborationHandoffResults{Items: []CollaborationHandoffResult{}}, WakeupCauses: CollaborationHandoffCauses{Items: []CollaborationHandoffCause{}, Completeness: "unknown"}, Sources: []CollaborationHandoffSource{}, Missing: []string{}}
}

func TestCollaborationHandoffRejectsFalseCompletenessAndUnknownVersion(t *testing.T) {
	base := testHandoffEnvelope()
	if err := ValidateCollaborationHandoff(base); err != nil {
		t.Fatal(err)
	}
	for _, mutate := range []func(*CollaborationHandoffEnvelope){
		func(v *CollaborationHandoffEnvelope) { v.ProtocolVersion = 2 },
		func(v *CollaborationHandoffEnvelope) { v.Inputs.Items = nil },
		func(v *CollaborationHandoffEnvelope) { v.Inputs.NextCursor = "unexpected" },
		func(v *CollaborationHandoffEnvelope) { v.Memory.Availability = "available"; v.Memory.Version = "1" },
		func(v *CollaborationHandoffEnvelope) {
			v.Sources = append(v.Sources, CollaborationHandoffSource{Kind: "system_instruction", ID: v.IssueID})
		},
	} {
		v := testHandoffEnvelope()
		mutate(&v)
		if ValidateCollaborationHandoff(v) == nil {
			t.Fatalf("accepted malformed handoff: %+v", v)
		}
	}
}

func TestCollaborationHandoffWireRejectsUnrecognizedAuthority(t *testing.T) {
	v := testHandoffEnvelope()
	raw, _ := json.Marshal(v)
	var roundtrip CollaborationHandoffEnvelope
	if err := json.Unmarshal(raw, &roundtrip); err != nil {
		t.Fatal(err)
	}
	raw = append(raw[:len(raw)-1], []byte(`,"allow_all_tools":true}`)...)
	if json.Unmarshal(raw, &roundtrip) == nil {
		t.Fatal("unknown authority field accepted")
	}
}
