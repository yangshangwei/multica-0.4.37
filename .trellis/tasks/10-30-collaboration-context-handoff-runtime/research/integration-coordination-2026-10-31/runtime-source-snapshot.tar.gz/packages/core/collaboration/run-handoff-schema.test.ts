// @vitest-environment node
import { afterEach, expect, it, vi } from "vitest";
import { ApiClient } from "../api/client";
import { parseCollaborationRunHandoff } from "./run-handoff-schema";

const id = "00000000-0000-4000-8000-000000000001";
const other = "00000000-0000-4000-8000-000000000002";
const page = { total: 0, returned: 0, truncated: false, items: [] };
const handoff = { protocol_version: 1, issue_id: id, run_id: other, mode: "live", event_seq: "9007199254740993",
  authority: { status: "in_progress", handler_id: id }, assignment: { role: "agent", step_key: "agent" }, handoff: null, information_request: null,
  memory: { version: "0", availability: "absent" }, inputs: page, results: page, wakeup_causes: { ...page, completeness: "unknown" }, sources: [], missing: [] };
afterEach(() => vi.unstubAllGlobals());

it("preserves absence and exact handoff identity while refusing malformed declared support", () => {
  expect(parseCollaborationRunHandoff(handoff)).toEqual(handoff);
  expect(parseCollaborationRunHandoff(undefined)).toBeNull();
  for (const patch of [{ protocol_version: 2 }, { mode: "snapshot" }, { authority: {} }, { results: {} },
    { results: { ...page, returned: 1 } }, { wakeup_causes: { ...page, completeness: "complete" } }, { missing: undefined }]) {
    expect(parseCollaborationRunHandoff({ ...handoff, ...patch })).toBeNull();
  }
  const source = { kind: "provider_result", id, run_id: other, sha256: "a".repeat(64), content: "Provider output", truncated: false, availability: "available", trust: "data_only" };
  expect(parseCollaborationRunHandoff({ ...handoff, sources: [source] })?.sources[0]?.trust).toBe("data_only");
  expect(parseCollaborationRunHandoff({ ...handoff, sources: [{ ...source, trust: "admitted_assignment" }] })).toBeNull();
  expect(parseCollaborationRunHandoff({ ...handoff, sources: [{ ...source, availability: "purged" }] })).toBeNull();
});

it("uses the human handoff endpoint and rejects a response for a different run", async () => {
  const fetch = vi.fn().mockResolvedValueOnce(new Response(JSON.stringify(handoff)))
    .mockResolvedValueOnce(new Response(JSON.stringify({ ...handoff, run_id: id })))
    .mockResolvedValueOnce(new Response("not found", { status: 404 }));
  vi.stubGlobal("fetch", fetch);
  const api = new ApiClient("https://handoff.example");
  expect(await api.getCollaborationRunHandoff(id, other)).toEqual(handoff);
  expect(fetch.mock.calls[0]?.[0]).toContain(`/api/collaboration/issues/${id}/runs/${other}/handoff`);
  expect(await api.getCollaborationRunHandoff(id, other)).toBeNull();
  expect(await api.getCollaborationRunHandoff(id, other)).toBeNull();
  expect(fetch.mock.calls.every(([url]) => !url.includes("/runtime/"))).toBe(true);
});
